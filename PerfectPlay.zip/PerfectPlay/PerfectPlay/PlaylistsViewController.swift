//
//  PlaylistsViewController.swift
//  PerfectPlay
//
//  Created by Brooke Ly on 3/5/18.
//  Copyright © 2018 Brooke Ly. All rights reserved.
//

import UIKit
import GooglePlaces
import CoreLocation
import HealthKit

class PlaylistsViewController: UIViewController, CLLocationManagerDelegate, UITableViewDataSource, UITableViewDelegate {
    
    var placesClient: GMSPlacesClient!
    var locationManager = CLLocationManager()
    var placeToGenre: [String: String] = [:]
    var playlists = [SPTPartialPlaylist]()
    var session: SPTSession!
    var userId: String?
    var accessToken: String?
    var name: String?
    var type: String!
    
    let dateFormatter = DateFormatter()
    
    var placeType = "university"
    var hrefLinkToSend: String!
    
    let healthStore = HKHealthStore()
    var heartRate: Double?
    var heartRates = [Double]()
    var heartRateDateLog = [String]()
    
    @IBOutlet weak var tableView: UITableView!
    var typeToCategories = ["gym":"workout","school":"focus","university":"focus","library":"focus","cafe":"chill","airport":"travel"]
    
    var nameArray = [String]()
    var imageArray = [String]()
    var hrefArray = [String]()
    @IBOutlet weak var greeting: UILabel!
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (nameArray.count)
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! PlaylistVCTableViewCell
        
        let imageUrlString = imageArray[indexPath.row]
        let imageUrl:URL = URL(string: imageUrlString)!
        // Start background thread so that image loading does not make app unresponsive
        DispatchQueue.global(qos: .userInitiated).async {
            
            let imageData:NSData = NSData(contentsOf: imageUrl)!
            
            DispatchQueue.main.async {
                let image = UIImage(data: imageData as Data)
                cell.myImage.image = image
            }
        }
        cell.myImage.image = UIImage(named: imageArray[indexPath.row])
        cell.myLabel.text = nameArray[indexPath.row]
        return (cell)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //print("accessToken from PlaylistsViewController: ", accessToken, "userID: ", userId)
        getPlaylists()
        getHeartRate()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        locationManager.requestAlwaysAuthorization()
        let placeID = "ChIJkb-SJQ7e3IAR7LfattDF-3k" //UC Irvine
        placesClient = GMSPlacesClient.shared()
        placesClient.lookUpPlaceID(placeID, callback: { (place, error) -> Void in
            if let error = error {
                print("lookup place id query error: \(error.localizedDescription)")
                return
            }
            guard let place = place else {
                print("No place details for \(placeID)")
                return
            }
            self.name = place.name
            print("Place name: \(place.name)")
            print("Place address: \(String(describing: place.formattedAddress))")
            print("Place types: \(String(describing: place.types))")
            if place.types.contains("university") {
                self.type = "university"
//                self.greeting.text = "You're at school!**"
            }
        })
        
    }
    
    private func getPlaylistData(serverURL:URL ,completion:@escaping (AnyObject) ->()){
        let task = URLSession.shared.dataTask(with: serverURL) { (data, response, error) in
            if error != nil {
                print ("Error retrieving URLSession")
            }
            else
            {
                if let content = data
                {
                    do
                    {
                        let JSONData = try JSONSerialization.jsonObject(with: content, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        completion(JSONData)
                        
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
                        print(self.hrefArray)
                    }
                    catch
                    {
                        print("Error in trying JSONSerialization")
                    }
                }
            }
        }
        task.resume()
    }
    
    func getPlaylists(){
        let apiURL = "https://api.spotify.com/v1/browse/categories/focus/playlists?access_token=" + accessToken!
        print("apiURL: ", apiURL)
        let url = URL(string: apiURL)
        
        getPlaylistData(serverURL: url!, completion: { serverResponse in
            if let nestedDictionary = serverResponse["playlists"] as? [String: Any] {
                // access nested dictionary values by key
                if let items = nestedDictionary["items"] as? [Dictionary<String, Any>]{
                    for key in items {
                        self.nameArray.append(key["name"] as! String)
                        self.hrefArray.append(key["href"] as! String)
                        let url = key["images"] as? [Dictionary<String, Any>]
                        for k in url!{
                            self.imageArray.append(k["url"] as! String)
                        }
                    }
                }
            }
        })
    }
    
    func getHeartRate(){
        let heartRateType = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!
        
        if (HKHealthStore.isHealthDataAvailable()){
            self.healthStore.requestAuthorization(toShare: nil, read:[heartRateType], completion:{(success, error) in
                let sortByTime = NSSortDescriptor(key:HKSampleSortIdentifierEndDate, ascending:false)
                
                self.dateFormatter.dateFormat = "MM/dd/YYYY"
                
                let query = HKSampleQuery(sampleType:heartRateType, predicate:nil, limit:600, sortDescriptors:[sortByTime], resultsHandler:{(query, results, error) in
                    guard let results = results else { return }
                    if results.count == 0 {
                        self.heartRate = 0
                    }
                    else {
                        for quantitySample in results {
                            let heartRateUnit = HKUnit(from: "count/min")
                            let quantity = (quantitySample as! HKQuantitySample).quantity
                            self.heartRates.append(quantity.doubleValue(for: heartRateUnit))
                            self.heartRateDateLog.append(self.dateFormatter.string(from: quantitySample.startDate))
                        }
                        print("Results: ", results)
                        //print("most recent heart rate: ", self.heartRates[self.heartRates.count-1])
                    }
                })
                self.healthStore.execute(query)
            })
        }
    }
    
    @IBAction func chooseRandomPlaylist(_ sender: Any) {
        let size = hrefArray.count
        let randomIndex = arc4random_uniform(UInt32(size))
        ///print("Random Index: " + String(randomIndex))
        hrefLinkToSend = self.hrefArray[Int(randomIndex)]
        performSegue(withIdentifier: "sendPlaylistID", sender: (Any).self)
        
    }
    
    @IBAction func measureHeartRateClicked(_ sender: Any) {
        let currentDate = Date()
        let result = dateFormatter.string(from: currentDate)
        print("Today is: ", result)
        print("recorded dates: ", self.heartRateDateLog)
        if self.heartRateDateLog.count == 0 {
            print("Alert Message: You do not have any previous Heart Rate data, please do so to proceed")
            let alert = UIAlertController(title: "Alert", message: "Message", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
                switch action.style{
                case .default:
                    print("default")
                    
                case .cancel:
                    print("cancel")
                    
                case .destructive:
                    print("destructive")
                    
                    
                }}))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            if self.heartRateDateLog.contains(result){
                print("Yes. Now I want to send heart rate through the segue")
                performSegue(withIdentifier: "sendHeartRate", sender: (Any).self)
            }
            else{
                print("Alert Message: No recent HR recording")
                //alert msessage you dont a hr
            }
        }
        print("All heart rates: ", self.heartRates) //[self.heartRates.count-1]
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "sendPlaylistID"{
            let vc1 = segue.destination as! ChooseForMeVC
            vc1.hreflink = hrefLinkToSend
        }
        if segue.identifier == "sendSpecificPlaylistID"{
            let vcDest = segue.destination as! ChooseForMeVC
            hrefLinkToSend = self.hrefArray[(tableView.indexPathForSelectedRow?.row)!]
            vcDest.hreflink = hrefLinkToSend
        }
        if segue.identifier == "sendHeartRate"{
            print("in sendHeartRate prepare")
            let vcDest1 = segue.destination as! HeartRateViewController
            vcDest1.heartRate = self.heartRates[0] //send the first element in the array
        }
    }
    
}
