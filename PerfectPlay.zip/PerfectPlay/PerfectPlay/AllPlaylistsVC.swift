//
//  AllPlaylistsVC.swift
//  PerfectPlay
//
//  Created by Brooke Ly on 2/27/18.
//  Copyright © 2018 Brooke Ly. All rights reserved.
//

import UIKit
import GooglePlaces
import CoreLocation
import HealthKit

class AllPlaylistsVC: UIViewController, CLLocationManagerDelegate {
    
    var placesClient: GMSPlacesClient!
    var locationManager = CLLocationManager()
    var placeToGenre: [String: String] = [:]
    let healthStore = HKHealthStore()
    var speed: CLLocationSpeed = CLLocationSpeed()
    var accessTokenA: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Access Token in AllPlaylistsVC: " , accessTokenA as Any)
        let placeID = "ChIJkb-SJQ7e3IAR7LfattDF-3k" //UC Irvine
        placesClient = GMSPlacesClient.shared()
        placesClient.lookUpPlaceID(placeID, callback: { (place, error) -> Void in
            if let error = error {
                print("lookup place id query error: \(error.localizedDescription)")
                return
            }
            
            guard let place = place else {
                print("No place details for \(placeID)")
                return
            }
            print("-------")
            print("Place name: \(place.name)")
            print("Place address: \(String(describing: place.formattedAddress))")
            print("Place types: \(String(describing: place.types))")
            if place.types.contains("university") { //Focus genre. Some popular playlists: [Deep Focus, Brain Food]
                print("yes")
            }
        })
        
       
        var speed: CLLocationSpeed = CLLocationSpeed()
        speed = locationManager.location!.speed
        if (speed < 0){
            speed = 0
        }
        print("speed: ", String(format: "%.0f miles/hour", speed * 2.2369))
        
        let heartRateType = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!
        
        if (HKHealthStore.isHealthDataAvailable()){
            var csvString = "Time,Date,Heartrate(BPM)\n"
            self.healthStore.requestAuthorization(toShare: nil, read:[heartRateType], completion:{(success, error) in
                let sortByTime = NSSortDescriptor(key:HKSampleSortIdentifierEndDate, ascending:false)
                let timeFormatter = DateFormatter()
                timeFormatter.dateFormat = "hh:mm:ss"
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MM/dd/YYYY"
                
                
                let query = HKSampleQuery(sampleType:heartRateType, predicate:nil, limit:600, sortDescriptors:[sortByTime], resultsHandler:{(query, results, error) in
                    guard let results = results else { return }
                    for quantitySample in results {
                        let quantity = (quantitySample as! HKQuantitySample).quantity
                        let heartRateUnit = HKUnit(from: "count/min")
                        csvString += "\(timeFormatter.string(from: quantitySample.startDate)),\(dateFormatter.string(from: quantitySample.startDate)),\(quantity.doubleValue(for: heartRateUnit))\n"
                        print("\(timeFormatter.string(from: quantitySample.startDate)),\(dateFormatter.string(from: quantitySample.startDate)),\(quantity.doubleValue(for: heartRateUnit))")
                    }
                })
                self.healthStore.execute(query)
            })
        }
    }
    
}
