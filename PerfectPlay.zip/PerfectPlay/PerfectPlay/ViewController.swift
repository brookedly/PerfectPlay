//
//  ViewController.swift
//  PerfectPlay
//
//  Created by Brooke Ly on 2/27/18.
//  Copyright © 2018 Brooke Ly. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, SPTAudioStreamingPlaybackDelegate, SPTAudioStreamingDelegate {

    let redirectURL = "PerfectPlay://returnAfterLogin" // put your redirect URL here
    let clientID = "1a98c58667ae4c2eafad6799bd5a2dc4"
    var locationManager = CLLocationManager()
    var loginUrl: URL?
    var session:SPTSession!
    var player:SPTAudioStreamingController?
    var auth = SPTAuth.defaultInstance()!
    var accessToken: String = ""
    var userId: String = ""
    let morning: String = "https://api.spotify.com/v1/user/spotify/playlist/2lDJ2xtmpCSN9CO7ZBkIVc"
    let evening: String = "https://api.spotify.com/v1/user/spotify/playlist/37i9dQZF1DX3bSdu6sAEDF"
    let afternoon: String = "https://api.spotify.com/v1/user/spotify/playlist/37i9dQZF1DX4E3UdUs7fUx"
    let date = Date()
    let calendar = Calendar.current
    @IBOutlet weak var loginButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.updateAfterFirstLogin), name: NSNotification.Name(rawValue: "loginSuccessfull"), object: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setup () {
        // insert redirect your url and client ID below
        let redirectURL = "PerfectPlay://returnAfterLogin" // put your redirect URL here
        let clientID = "1a98c58667ae4c2eafad6799bd5a2dc4" // put your client ID here
        auth.redirectURL     = URL(string: redirectURL)
        auth.clientID        = clientID
        auth.requestedScopes = [SPTAuthStreamingScope, SPTAuthPlaylistReadPrivateScope, SPTAuthPlaylistModifyPublicScope, SPTAuthPlaylistModifyPrivateScope]
        loginUrl = auth.spotifyWebAuthenticationURL()
    }
    
    func initializePlayer(authSession:SPTSession){
        if self.player == nil {
            self.player = SPTAudioStreamingController.sharedInstance()
            self.player!.playbackDelegate = self
            self.player!.delegate = self
            try! player?.start(withClientId: auth.clientID)
            self.player!.login(withAccessToken: authSession.accessToken)
            accessToken = authSession.accessToken
            print("access token in VC: ", accessToken)
        }
    }
    
    @objc func updateAfterFirstLogin () {
        loginButton.isHidden = true
        let userDefaults = UserDefaults.standard
        
        if let sessionObj:AnyObject = userDefaults.object(forKey: "SpotifySession") as AnyObject? {
            let sessionDataObj = sessionObj as! Data
            let firstTimeSession = NSKeyedUnarchiver.unarchiveObject(with: sessionDataObj) as! SPTSession
            self.session = firstTimeSession
            self.userId = self.session.canonicalUsername
            if !session.isValid(){
                SPTAuth.defaultInstance().renewSession(SPTAuth.defaultInstance().session, callback: { (error, session) in
                    if error == nil {
                        let sessionData = NSKeyedArchiver.archivedData(withRootObject: session as Any)
                        userDefaults.set(sessionData, forKey: "SpotifySession")
                        userDefaults.synchronize()
                    }
                    else {
                        print("error refreshing session")
                    }
                })
            }
            else{
                print("session is still valid")
                //self.playUsingSession(session)
            }
            
            initializePlayer(authSession: session)
            
        }
        
//        var speed: CLLocationSpeed = CLLocationSpeed()
//        speed = locationManager.location!.speed
//        if (speed < 0){
//            speed = 0
//        }
        
       var speed = 2  //used to manually test all cases
        
        
        if speed < 5 {
            print("Speed is less than 5")
            performSegue(withIdentifier: "sendAccessToken", sender: (Any).self)

            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let TabBarVC = storyBoard.instantiateViewController(withIdentifier: "TabBarVC")
            self.present(TabBarVC, animated: true, completion: nil)
        }
        else if speed > 5 && speed < 15 { //cruisen or running hella fast lol
            print("speed is between 5 and 15")
            //play top track playlists?
            
        }
        else {
            //Speed greater than 15
            print("Speed greater than 15")
            performSegue(withIdentifier: "safeMode", sender: (Any).self)
//            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
//            print("1")
//            let ChooseForMeVC = storyBoard.instantiateViewController(withIdentifier: "ChooseForMeVC")
//              print("2")
//            self.present(ChooseForMeVC, animated: true, completion: nil)
//              print("3")
        }
        
    }
    
    func audioStreamingDidLogin(_ audioStreaming: SPTAudioStreamingController!) {
        // after a user authenticates a session, the SPTAudioStreamingController is then initialized and this method called
        print("logged in")
//        self.player?.playSpotifyURI("spotify:track:630sXRhIcfwr2e4RdNtjKN", startingWith: 0, startingWithPosition: 0, callback: { (error) in
//            if (error != nil) {
//                print("playing!")
//            }
//        })
    }
    
    @IBAction func loginWithSpotify(_ sender: Any) {
        SPTAuth.defaultInstance().clientID = clientID
        SPTAuth.defaultInstance().redirectURL = URL(string: redirectURL)
        SPTAuth.defaultInstance().requestedScopes = [SPTAuthStreamingScope, SPTAuthPlaylistReadPrivateScope, SPTAuthPlaylistModifyPublicScope, SPTAuthPlaylistModifyPrivateScope]
        loginUrl = SPTAuth.defaultInstance().spotifyWebAuthenticationURL()
        
        if UIApplication.shared.canOpenURL(loginUrl!) {
            print("CAN OPEN URL")
            UIApplication.shared.open(loginUrl!)
            if auth.canHandle(auth.redirectURL) {
                // To do - build in error handling
            }
        }
        else{
            print("rip cant open url")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // 3-11 == 3am-11am
        // 12-15 == 12-3pm
        // 16-2 == 4pm-2am
        let hour = calendar.component(.hour, from: date)
//        let hour = 1
        if segue.identifier == "safeMode"{
            print("Hour: ", hour)
            print("safeMode prepare segue")
            let vc = segue.destination as! ChooseForMeVC
            if hour >= 3 && hour <= 11{
                print("MORNING COMMUTE")
                 vc.hreflink = self.morning
            }
            if hour >= 12 && hour <= 15 {
                print("AFTERNOON GRIND")
                vc.hreflink = self.afternoon
            }
            if  (hour >= 16 && hour <= 25) || (hour >= 0 && hour <= 2) {
                print("EVENING COMMUTE")
                 vc.hreflink = self.evening
            }
        }
        if segue.identifier == "sendAccessToken"{
            print("sendAccessToken Prepare")
            let vc1 = segue.destination as! PlaylistsViewController
            vc1.accessToken = self.accessToken
            vc1.userId = self.userId
        }
    }
}

//AIzaSyA1ZXR7sBppmOKixwOtMOanPmzOJtZMg-c
