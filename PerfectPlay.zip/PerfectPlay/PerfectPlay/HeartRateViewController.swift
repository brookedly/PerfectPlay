//
//  HeartRateViewController.swift
//  PerfectPlay
//
//  Created by Brooke Ly on 3/14/18.
//  Copyright © 2018 Brooke Ly. All rights reserved.
//

import UIKit
import WebKit

class HeartRateViewController:UIViewController {
    
    var heartRate: Double?
    @IBOutlet weak var spotifyViewH: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("in HeartRateViewController heart rate is: ", heartRate)
        loadViewBasedOnRate()
    
    }
    func loadViewBasedOnRate() {
        //HIGH 31lxxIDyC3qYrtH6TpGFwx
        let width: CGFloat = spotifyViewH.frame.size.width
        let height: CGFloat = spotifyViewH.frame.size.height
        let URL: String!
        if heartRate! > Double(90) {
            print("greater than 90")
            URL = String(format: "<iframe src=\"https://open.spotify.com/user/1286544262/playlist/31lxxIDyC3qYrtH6TpGFwx\" width=\"%f\" height=\"%f\" frameborder=\"0\" allowtransparency=\"true\" allow=\"encrypted-media\"></iframe>", width * 3.0, height * 3.0)
        }
        
        //resting -- for now recommending a random playlist
        // ideally -- we want to tie the recommendation to the user's music history
        else if heartRate! < Double(90) && heartRate! > Double(65){
            print("between 65 - 90")
            URL = String(format: "<iframe src=\"https://open.spotify.com/user/spotifycharts/playlist/37i9dQZEVXbLRQDuF5jeBp\" width=\"%f\" height=\"%f\" frameborder=\"0\" allowtransparency=\"true\" allow=\"encrypted-media\"></iframe>", width * 3.0, height * 3.0)
        }
        //LOW
        else {
            print("lower than 65")
            URL = String(format: "<iframe src=\"https://open.spotify.com/user/1286544262/playlist/31lxxIDyC3qYrtH6TpGFwx\" width=\"%f\" height=\"%f\" frameborder=\"0\" allowtransparency=\"true\" allow=\"encrypted-media\"></iframe>", width * 3.0, height * 3.0)
        }
        spotifyViewH.loadHTMLString(URL, baseURL: nil)
    }
}
