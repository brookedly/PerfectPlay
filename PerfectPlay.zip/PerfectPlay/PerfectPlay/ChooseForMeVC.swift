//
//  ChooseForMeVC.swift
//  PerfectPlay
//
//  Created by Brooke Ly on 3/12/18.
//  Copyright © 2018 Brooke Ly. All rights reserved.
//

import UIKit
import WebKit
import HealthKit

class ChooseForMeVC:UIViewController {
    
    @IBOutlet weak var spotifyView: WKWebView!
    let healthStore = HKHealthStore()
    var hreflink: String!
    var heartRate: Double?
    var heartRates = [Double]()

    override func viewDidLoad() {
        print("I got the id: ", hreflink)
        
        let hrefArr = hreflink.components(separatedBy: "/")
        print("Split Href: " , hrefArr)

        let width: CGFloat = spotifyView.frame.size.width
        let height: CGFloat = spotifyView.frame.size.height
        let URL = String(format: "<iframe src=\"https://open.spotify.com/embed/user/spotify/playlist/\(hrefArr[7])\" width=\"%f\" height=\"%f\" frameborder=\"0\" allowtransparency=\"true\" allow=\"encrypted-media\"></iframe>", width * 3.0, height * 3.0)
        spotifyView.loadHTMLString(URL, baseURL: nil)
        getHeartRate()
        print("Heart Rate: ", self.heartRate ?? 0) //nil for some reason
        
    }
    
    func getHeartRate(){
        let heartRateType = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!

        if (HKHealthStore.isHealthDataAvailable()){
            self.healthStore.requestAuthorization(toShare: nil, read:[heartRateType], completion:{(success, error) in
                let sortByTime = NSSortDescriptor(key:HKSampleSortIdentifierEndDate, ascending:false)
                
                let query = HKSampleQuery(sampleType:heartRateType, predicate:nil, limit:600, sortDescriptors:[sortByTime], resultsHandler:{(query, results, error) in
                    guard let results = results else { return }
                    if results.count == 0 {
                        self.heartRate = 0
                    }
                    else {
                        for quantitySample in results {
                            let heartRateUnit = HKUnit(from: "count/min")
                            let quantity = (quantitySample as! HKQuantitySample).quantity
                            self.heartRates.append(quantity.doubleValue(for: heartRateUnit))
                        }
                        print("Results: ", results)
                        print("most recent heart rate: ", self.heartRates[self.heartRates.count-1])
                    }
                })
                self.healthStore.execute(query)
            })
        }
    }
}


//heart rate recordings are listed from oldest to newest --> so the newest recording is at the beginning of the array.
